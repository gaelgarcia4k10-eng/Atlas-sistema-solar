/* ===== Atlas del Sistema Solar: interactividad ===== */
"use strict";

/* ---------- 1. Dato aleatorio (página de inicio) ---------- */
(function () {
  var texto = document.getElementById("dato-texto");
  var boton = document.getElementById("dato-boton");
  if (!texto || !boton) return;

  var datos = [
    "En Mercurio, un día completo (de un amanecer al siguiente) dura unos 176 días terrestres, más que su año de 88 días.",
    "Venus gira en sentido contrario a casi todos los planetas: allí el Sol sale por el oeste.",
    "El Monte Olimpo, en Marte, mide cerca de 22 km de altura: unas 2,5 veces el Everest.",
    "Júpiter es tan grande que dentro de él cabrían más de 1 300 planetas como la Tierra.",
    "Los anillos de Saturno miden cientos de miles de kilómetros de ancho, pero suelen tener solo decenas de metros de grosor.",
    "Urano gira «acostado»: su eje está inclinado unos 98 grados, así que rueda casi de lado alrededor del Sol.",
    "En Neptuno soplan los vientos más veloces del Sistema Solar, de más de 2 000 km/h.",
    "La Luna se aleja de la Tierra unos 3,8 centímetros cada año, más o menos lo que crecen tus uñas.",
    "El Sol contiene el 99,86 % de toda la masa del Sistema Solar."
  ];

  var ultimo = -1;
  boton.addEventListener("click", function () {
    var i;
    do { i = Math.floor(Math.random() * datos.length); } while (i === ultimo);
    ultimo = i;
    texto.textContent = datos[i];
  });
})();

/* ---------- 2. Calculadora de peso ---------- */
(function () {
  var form = document.getElementById("form-peso");
  var salida = document.getElementById("resultado-peso");
  if (!form || !salida) return;

  var gravedad = [
    ["Mercurio", 0.38], ["Venus", 0.91], ["la Luna", 0.165], ["Marte", 0.38],
    ["Júpiter", 2.53], ["Saturno", 1.07], ["Urano", 0.89], ["Neptuno", 1.14]
  ];

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var masa = parseFloat(document.getElementById("peso").value);
    salida.textContent = "";

    if (isNaN(masa) || masa <= 0 || masa > 500) {
      salida.textContent = "Escribe un peso válido entre 1 y 500 kg.";
      return;
    }

    var intro = document.createElement("p");
    intro.textContent = "Si pesas " + masa + " kg en la Tierra, tu peso sería:";
    var lista = document.createElement("ul");

    gravedad.forEach(function (g) {
      var li = document.createElement("li");
      var fuerte = document.createElement("strong");
      fuerte.textContent = (masa * g[1]).toFixed(1) + " kg";
      li.appendChild(fuerte);
      li.appendChild(document.createTextNode(" en " + g[0]));
      lista.appendChild(li);
    });

    salida.appendChild(intro);
    salida.appendChild(lista);
  });
})();

/* ---------- 3. Calculadora de edad ---------- */
(function () {
  var form = document.getElementById("form-edad");
  var salida = document.getElementById("resultado-edad");
  if (!form || !salida) return;

  var periodos = [
    ["Mercurio", 0.2408], ["Venus", 0.6152], ["Marte", 1.8808],
    ["Júpiter", 11.862], ["Saturno", 29.457], ["Urano", 84.01], ["Neptuno", 164.8]
  ];

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var edad = parseFloat(document.getElementById("edad").value);
    salida.textContent = "";

    if (isNaN(edad) || edad < 0 || edad > 120) {
      salida.textContent = "Escribe una edad válida entre 0 y 120 años.";
      return;
    }

    var intro = document.createElement("p");
    intro.textContent = "Con " + edad + " años terrestres, tendrías:";
    var lista = document.createElement("ul");

    periodos.forEach(function (p) {
      var li = document.createElement("li");
      var fuerte = document.createElement("strong");
      fuerte.textContent = (edad / p[1]).toFixed(1) + " años";
      li.appendChild(fuerte);
      li.appendChild(document.createTextNode(" en " + p[0]));
      lista.appendChild(li);
    });

    salida.appendChild(intro);
    salida.appendChild(lista);
  });
})();

/* ---------- 4. Cuestionario ---------- */
(function () {
  var form = document.getElementById("quiz-form");
  var contenedor = document.getElementById("quiz-contenedor");
  var resultado = document.getElementById("quiz-resultado");
  if (!form || !contenedor || !resultado) return;

  var preguntas = [
    { q: "¿Cuál es el planeta más grande del Sistema Solar?",
      o: ["Saturno", "Júpiter", "Neptuno"], c: 1,
      e: "Júpiter tiene un diámetro de casi 140 000 km." },
    { q: "¿Qué planeta tiene la temperatura superficial más alta?",
      o: ["Mercurio", "Venus", "Marte"], c: 1,
      e: "Venus ronda los 465 °C por el efecto invernadero de su atmósfera, aunque Mercurio esté más cerca del Sol." },
    { q: "¿Cuánto tarda la luz del Sol en llegar a la Tierra?",
      o: ["Unos 8 minutos", "Unos 8 segundos", "Unas 8 horas"], c: 0,
      e: "La luz recorre unos 150 millones de kilómetros en poco más de 8 minutos." },
    { q: "¿En qué planeta está el volcán más alto conocido?",
      o: ["Venus", "La Tierra", "Marte"], c: 2,
      e: "El Monte Olimpo, en Marte, mide cerca de 22 km." },
    { q: "¿Qué planeta gira prácticamente «de lado»?",
      o: ["Urano", "Júpiter", "Mercurio"], c: 0,
      e: "El eje de Urano está inclinado unos 98 grados." },
    { q: "¿Quién fue el primer mexicano en viajar al espacio?",
      o: ["José Hernández", "Rodolfo Neri Vela", "Carlos Slim"], c: 1,
      e: "Rodolfo Neri Vela voló en el transbordador Atlantis en noviembre de 1985." },
    { q: "¿Qué planeta es menos denso que el agua?",
      o: ["Saturno", "La Tierra", "Neptuno"], c: 0,
      e: "Su densidad media es de unos 0,69 g/cm³, menor que la del agua (1 g/cm³)." },
    { q: "¿Qué misión llevó a los primeros seres humanos a la Luna?",
      o: ["Apolo 11", "Voyager 1", "Sputnik 1"], c: 0,
      e: "Neil Armstrong y Buzz Aldrin pisaron la Luna el 20 de julio de 1969." }
  ];

  preguntas.forEach(function (p, i) {
    var fs = document.createElement("fieldset");
    fs.className = "pregunta";
    fs.id = "pregunta-" + i;

    var lg = document.createElement("legend");
    lg.textContent = (i + 1) + ". " + p.q;
    fs.appendChild(lg);

    p.o.forEach(function (op, j) {
      var lab = document.createElement("label");
      var inp = document.createElement("input");
      inp.type = "radio";
      inp.name = "p" + i;
      inp.value = j;
      lab.appendChild(inp);
      lab.appendChild(document.createTextNode(" " + op));
      fs.appendChild(lab);
    });

    var ex = document.createElement("p");
    ex.className = "explica";
    ex.hidden = true;
    fs.appendChild(ex);

    contenedor.appendChild(fs);
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var aciertos = 0;
    var sinResponder = 0;

    preguntas.forEach(function (p, i) {
      var fs = document.getElementById("pregunta-" + i);
      var marcada = form.querySelector('input[name="p' + i + '"]:checked');
      var ex = fs.querySelector(".explica");
      fs.classList.remove("acierto", "fallo");

      if (!marcada) {
        sinResponder++;
        ex.hidden = true;
        return;
      }

      var correcta = parseInt(marcada.value, 10) === p.c;
      if (correcta) aciertos++;
      fs.classList.add(correcta ? "acierto" : "fallo");
      ex.textContent = (correcta ? "¡Correcto! " : "Respuesta correcta: " + p.o[p.c] + ". ") + p.e;
      ex.hidden = false;
    });

    if (sinResponder > 0) {
      resultado.textContent = "Te faltan " + sinResponder + " pregunta(s) por responder.";
      return;
    }

    var mensaje;
    if (aciertos === preguntas.length) mensaje = "¡Perfecto! Eres astronauta de primera clase.";
    else if (aciertos >= 6) mensaje = "¡Muy bien! Casi eres experto en el Sistema Solar.";
    else if (aciertos >= 4) mensaje = "Vas por buen camino. Repasa las páginas e inténtalo otra vez.";
    else mensaje = "Es un buen comienzo. Revisa la página de planetas y vuelve a intentarlo.";

    resultado.textContent = "";
    var pt = document.createElement("span");
    pt.className = "puntaje";
    pt.textContent = aciertos + " de " + preguntas.length + " aciertos. ";
    resultado.appendChild(pt);
    resultado.appendChild(document.createTextNode(mensaje));
  });

  form.addEventListener("reset", function () {
    resultado.textContent = "";
    preguntas.forEach(function (p, i) {
      var fs = document.getElementById("pregunta-" + i);
      fs.classList.remove("acierto", "fallo");
      fs.querySelector(".explica").hidden = true;
    });
  });
})();
